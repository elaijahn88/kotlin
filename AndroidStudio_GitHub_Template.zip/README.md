# Android Studio GitHub Template

Basic Android project structure.
